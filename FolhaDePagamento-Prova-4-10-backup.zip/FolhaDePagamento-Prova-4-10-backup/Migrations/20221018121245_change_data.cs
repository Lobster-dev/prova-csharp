﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace FolhaDePagamento.Migrations
{
    public partial class change_data : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {

        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {

        }
    }
}
