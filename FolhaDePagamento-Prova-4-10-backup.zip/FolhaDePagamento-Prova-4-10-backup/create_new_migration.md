- **Adicionar uma nova migração**

```bash
dotnet ef migrations add NomeMigracao
```


- **Atualizar o banco de dados conforme a última migração**

```bash
dotnet ef database update
```