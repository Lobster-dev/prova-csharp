# How to start 

first clone the repository
`git clone`

then run the command below 
`dotnet restore`

than you can run the command 
`dotnet watch run`

# Criando uma migration com banco de dados em c#

